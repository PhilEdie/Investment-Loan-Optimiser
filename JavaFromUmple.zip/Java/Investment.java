/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.util.*;

// line 24 "model.ump"
// line 46 "model.ump"
public class Investment extends Node
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Investment(float aInterestRate, float aValue, int aMonth, Program aProgram)
  {
    super(aInterestRate, aValue, aMonth, aProgram);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}